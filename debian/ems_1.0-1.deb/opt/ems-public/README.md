# Element Management System
------


### Prerequisites

* python 2.7 
* stomp.py

### Usage

```bash
cd ..
python ems
```

### conf.ini

Inside the folder etc there is a configuration file, conf.ini, where:

* *orch_ip*: the ip of the NFVO
* *orch_port*: the port of NFVO